/**
 * 地球online — 玩家评测页面
 * 交互逻辑：星空背景、评测筛选、星级交互、搜索、持久化
 * @version 2026-05-17-v4  ← 如果控制台看到此版本号，说明加载了最新代码
 */

console.log('%c🌍 app.js v2026-05-17-v4 已加载', 'color:#d4a853;font-weight:bold;font-size:14px;');

/* ================================================================
   1. 评测数据
   ================================================================ */
const DEFAULT_REVIEWS = [
  // ========== 好评 ==========
  {
    id: 1,
    type: 'positive',
    username: '天命占星人',
    avatar: '🔮',
    server: '欧服·阿尔法',
    date: '2077-03-15',
    stars: 5,
    tag: '强烈推荐',
    text: '开局随机到北欧服务器，出生自带高福利社会属性，新手礼包直接送16年义务教育+全民医保。画面细节拉满，四季轮换真实到令人发指，NPC交互深度远超同类产品。虽然前期练级比较漫长，但坚持到20级后技能树逐渐丰富，值得长期投入。',
    likes: 2847,
    dislikes: 312,
    userLiked: false,
    userDisliked: false
  },
  {
    id: 2,
    type: 'positive',
    username: '星盘观测者',
    avatar: '🌙',
    server: '亚服·伽马',
    date: '2077-02-28',
    stars: 4,
    tag: '推荐',
    text: '自由度极高，你可以选择任何职业路线，没有强制主线任务。但新手教程约等于无，全靠自己摸索，前10级特别劝退。建议官方出一个更好的出生引导系统，不然新手死亡率太高了。不过熬过前期之后真香。',
    likes: 1923,
    dislikes: 456,
    userLiked: false,
    userDisliked: false
  },
  {
    id: 3,
    type: 'positive',
    username: '命运编织者',
    avatar: '🃏',
    server: '亚服·贝塔',
    date: '2076-12-01',
    stars: 5,
    tag: '神作',
    text: '我在这游戏里已经泡了8760个小时（约等于现实时间1年），依然觉得每天都有新内容。最绝的是这游戏的NPC每个都有独立人格和错综复杂的关系网，你永远不知道下一秒会触发什么隐藏剧情。唯一缺点：没法存档读档，一步走错可能影响整个周目。',
    likes: 3652,
    dislikes: 189,
    userLiked: false,
    userDisliked: false
  },
  {
    id: 4,
    type: 'positive',
    username: '秘仪学者',
    avatar: '📜',
    server: '亚服·阿尔法',
    date: '2077-01-20',
    stars: 4,
    tag: '值得一试',
    text: '音乐和美术无可挑剔，每个地图的场景设计都看得出花了血本。社交系统也是我见过最真实的——你永远不知道队友会不会在关键时刻下线。扣一星是因为最近的版本更新后，房价物价系统数值膨胀有点严重。',
    likes: 1567,
    dislikes: 534,
    userLiked: false,
    userDisliked: false
  },
  {
    id: 5,
    type: 'positive',
    username: '灵摆占卜师',
    avatar: '⚖️',
    server: '欧服·伽马',
    date: '2076-11-11',
    stars: 5,
    tag: '现象级',
    text: '二周目中选了hard模式开局，果然比一周目刺激多了。建议新手先选简单模式熟悉机制。这游戏的沉浸感无与伦比，已经安利给了所有还在排队等转生的朋友。',
    likes: 2210,
    dislikes: 298,
    userLiked: false,
    userDisliked: false
  },
  // ========== 差评 ==========
  {
    id: 6,
    type: 'negative',
    username: '破灭预言家',
    avatar: '💀',
    server: '亚服·阿尔法',
    date: '2077-03-10',
    stars: 1,
    tag: '极度不公',
    text: '氪金系统极度不平衡！有些玩家开局就是满配账号——出生在富裕家庭、高颜值、高智商属性点全满。而我们这些零氪玩家辛辛苦苦练到30级，还不如人家一个首充礼包。这游戏根本不公平，强烈建议所有玩家罢玩抗议！',
    likes: 5234,
    dislikes: 1021,
    userLiked: false,
    userDisliked: false
  },
  {
    id: 7,
    type: 'negative',
    username: '虚空旅者',
    avatar: '🌪️',
    server: '亚服·德尔塔',
    date: '2077-02-14',
    stars: 2,
    tag: '体验糟糕',
    text: '服务器卡顿严重，每天高峰时段都有明显延迟，有时候关键操作会直接卡掉线重连。特别是某些地图（早高峰地铁站、热门景区）简直PPT一样。优化做了这么多年还是这德行，程序员是摸鱼去了吗？',
    likes: 3891,
    dislikes: 765,
    userLiked: false,
    userDisliked: false
  },
  {
    id: 8,
    type: 'negative',
    username: '末日时钟匠',
    avatar: '⏳',
    server: '美服·贝塔',
    date: '2077-01-05',
    stars: 1,
    tag: '退游警告',
    text: 'PvP模式做得一塌糊涂！高等级玩家随便屠戮新手村，GM完全不管。竞技场里全是顶级装备的氪佬，零氪玩家进去就是送人头。这游戏已经彻底变成了pay-to-win，失望透顶，已卸载。',
    likes: 4456,
    dislikes: 892,
    userLiked: false,
    userDisliked: false
  },
  {
    id: 9,
    type: 'negative',
    username: '深渊回响',
    avatar: '🕳️',
    server: '亚服·阿尔法',
    date: '2076-12-24',
    stars: 2,
    tag: 'BUG太多',
    text: '恶性BUG多到令人发指：上周我在街上走着莫名其妙触发了一个"失业"DEBUFF，持续了6个月还没消除；朋友更惨，遇到了"房贷"永久绑定任务，据说要还30年现实时间才能完成。建议修复再上线。',
    likes: 3125,
    dislikes: 643,
    userLiked: false,
    userDisliked: false
  },
  {
    id: 10,
    type: 'negative',
    username: '终末记录官',
    avatar: '📖',
    server: '亚服·泽塔',
    date: '2076-10-31',
    stars: 3,
    tag: '差强人意',
    text: '中等偏下的体验。世界观确实宏大，但日常任务（上班/上学）重复度太高，收益又低。而且最近版本的健康系统更新后，熬夜挂机被强制下线了。说是为了玩家好，但我觉得管得太宽了。给三星是因为偶尔触发的隐藏任务（旅行/恋爱/奇遇）确实好玩。',
    likes: 1834,
    dislikes: 412,
    userLiked: false,
    userDisliked: false
  }
];

// 头像池（随机分配）
const AVATAR_POOL = ['🔮','🌙','🃏','📜','⚖️','💀','🌪️','⏳','🕳️','📖','🧙','🪐','🌈','🐉','🎭'];

// 标签映射
function getTag(type, stars) {
  if (type === 'positive') {
    return stars >= 5 ? '强烈推荐' : stars >= 4 ? '推荐' : '值得一试';
  }
  return stars <= 1 ? '极度不公' : stars <= 2 ? '体验糟糕' : '差强人意';
}

/* ================================================================
   1b. 数据持久化
   ================================================================ */
const STORAGE_KEY = 'earthonline_reviews';
const LOCKED_KEY = 'earthonline_locked';

// ★★★ API 地址配置 ★★★
// PHP 服务器（宝塔等）：'api.php?action='
// Node.js 服务器：       '/api/'
// 留空则跳过服务端请求，完全使用本地存储
const API_PREFIX = 'api.php?action=';

// 用于 Node.js 模式：'/api/'

// ★ 点赞状态本地存储 key
const LIKES_KEY = 'earthonline_likes';

function loadReviews() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed) && parsed.length > 0) return parsed;
  } catch (e) {
    console.warn('无法读取本地评测数据，使用默认数据。');
  }
  return null;
}

function saveReviews(reviews) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(reviews));
  } catch (e) {
    console.warn('本地存储已满，无法保存。');
  }
}

/* ★ 点赞状态持久化 — 独立于评测数据，刷新后仍保留 */
function loadLikesState() {
  try {
    const raw = localStorage.getItem(LIKES_KEY);
    if (!raw) return {};
    return JSON.parse(raw);
  } catch (e) {
    return {};
  }
}

function saveLikesState(state) {
  try {
    localStorage.setItem(LIKES_KEY, JSON.stringify(state));
  } catch (e) {
    console.warn('本地存储已满，无法保存点赞状态。');
  }
}

// 记录点赞/踩操作
function recordLike(reviewId, type) {
  const state = loadLikesState();
  const key = String(reviewId);
  if (!state[key]) state[key] = {};
  if (type === 'like') {
    state[key].liked = true;
    state[key].disliked = false;
  } else if (type === 'dislike') {
    state[key].liked = false;
    state[key].disliked = true;
  } else if (type === 'unlike') {
    state[key].liked = false;
  } else if (type === 'undislike') {
    state[key].disliked = false;
  }
  saveLikesState(state);
}

// 将点赞状态合并到评测数据
function mergeLikesState(reviews) {
  const state = loadLikesState();
  reviews.forEach(r => {
    const key = String(r.id);
    if (state[key]) {
      r.userLiked = !!state[key].liked;
      r.userDisliked = !!state[key].disliked;
    } else {
      r.userLiked = false;
      r.userDisliked = false;
    }
  });
  return reviews;
}

/* 评测锁定状态 — 纯客户端，只依赖当前浏览器自己的 localStorage 标记 */
function getCookie(name) {
  const match = document.cookie.match(new RegExp('(^| )' + name + '=([^;]+)'));
  return match ? match[2] : null;
}

function setCookie(name, value, days) {
  const d = new Date();
  d.setTime(d.getTime() + days * 86400000);
  document.cookie = name + '=' + value + ';expires=' + d.toUTCString() + ';path=/';
}

function isReviewLocked() {
  // Cookie（最可靠）
  if (getCookie('elo_locked') === '1') return true;
  // localStorage（辅助兜底）
  if (localStorage.getItem(LOCKED_KEY) === 'true') {
    setCookie('elo_locked', '1', 365);
    return true;
  }
  return false;
}

function lockReviewForm() {
  setCookie('elo_locked', '1', 365);
  try { localStorage.setItem(LOCKED_KEY, 'true'); } catch (e) {}
  console.log('🔒 评测表单已锁定');

  try {
    const section = document.querySelector('.write-review-section');
    if (section) {
      if (section.querySelector('.locked-state')) return;
      section.innerHTML = `
        <div class="locked-state">
          <span class="locked-icon">🔒</span>
          <h3 class="locked-title">你已留下过回声</h3>
          <p class="locked-desc">每个命运的印记只能回响一次 ✦</p>
          <p class="locked-sub">感谢你的分享，你的故事已被群星铭记。</p>
        </div>
      `;
    }
  } catch (e) {
    console.warn('DOM 替换失败:', e);
  }
}

// 从服务端获取评测数据（如果可用），同时获取 IP 锁定状态
async function fetchReviewsFromServer() {
  try {
    const resp = await fetch(API_PREFIX + 'reviews', { method: 'GET' });
    if (!resp.ok) return null;
    const data = await resp.json();
    if (data.success && Array.isArray(data.reviews)) {
      // ★ 同时返回 IP 锁定状态
      if (typeof data.hasSubmitted !== 'undefined') {
        window.__serverHasSubmitted = data.hasSubmitted;
      }
      if (data.clientIP) {
        console.log('🔒 服务端检测 IP:', data.clientIP, '已提交:', data.hasSubmitted);
      }
      return data.reviews;
    }
  } catch (e) {
    // 服务端不可用
  }
  return null;
}

// 初始化数据源 — 不再用 DEFAULT_REVIEWS 污染 localStorage
// 优先从服务端加载，其次 localStorage，最后才用默认数据（但不写入 localStorage）
let reviewsData = loadReviews() || [];

// 记录原有 ID 最大值用于新评测
let nextId = reviewsData.length > 0
  ? reviewsData.reduce((max, r) => Math.max(max, r.id), 0) + 1
  : 1;

/* ================================================================
   2. 星空粒子背景 (Canvas)
   ================================================================ */
function initStarfield() {
  const canvas = document.getElementById('starfield');
  if (!canvas) return;

  const ctx = canvas.getContext('2d');
  let w, h, stars = [];
  const COUNT = 160;

  function resize() {
    w = canvas.width = window.innerWidth;
    h = canvas.height = window.innerHeight;
  }
  resize();
  window.addEventListener('resize', resize);

  for (let i = 0; i < COUNT; i++) {
    stars.push({
      x: Math.random() * w,
      y: Math.random() * h,
      r: Math.random() * 1.8 + 0.2,
      dx: (Math.random() - 0.5) * 0.15,
      dy: (Math.random() - 0.5) * 0.15,
      alpha: Math.random() * 0.8 + 0.2,
      pulseSpeed: Math.random() * 0.02 + 0.005,
      pulsePhase: Math.random() * Math.PI * 2
    });
  }

  let frame = 0;
  function draw() {
    ctx.clearRect(0, 0, w, h);
    frame++;

    for (const s of stars) {
      s.x += s.dx;
      s.y += s.dy;
      if (s.x < 0) s.x = w;
      if (s.x > w) s.x = 0;
      if (s.y < 0) s.y = h;
      if (s.y > h) s.y = 0;

      const pulse = 0.6 + 0.4 * Math.sin(frame * s.pulseSpeed + s.pulsePhase);
      const alpha = s.alpha * pulse;

      ctx.beginPath();
      ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(255, 255, 255, ${alpha})`;
      ctx.fill();
    }

    // 稀疏散点连线
    for (let i = 0; i < stars.length; i++) {
      for (let j = i + 1; j < stars.length; j++) {
        const dx = stars[i].x - stars[j].x;
        const dy = stars[i].y - stars[j].y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < 100) {
          const alpha = (1 - dist / 100) * 0.08;
          ctx.beginPath();
          ctx.moveTo(stars[i].x, stars[i].y);
          ctx.lineTo(stars[j].x, stars[j].y);
          ctx.strokeStyle = `rgba(212, 168, 83, ${alpha})`;
          ctx.lineWidth = 0.5;
          ctx.stroke();
        }
      }
    }

    requestAnimationFrame(draw);
  }
  draw();
}

/* ================================================================
   3. 渲染助手
   ================================================================ */

/**
 * 渲染星级 — 只显示已点亮的星星，不显示空星
 * 用户要求：放几颗星才显示几颗星
 */
function renderStars(starCount) {
  let html = '';
  for (let i = 0; i < starCount; i++) {
    html += '<span class="star">★</span>';
  }
  return html;
}

function formatNumber(n) {
  if (n >= 10000) return (n / 10000).toFixed(1) + '万';
  if (n >= 1000) return (n / 1000).toFixed(1) + 'k';
  return n.toString();
}

function createReviewCard(review) {
  const card = document.createElement('div');
  const typeClass = review.type === 'positive' ? 'positive' : 'negative';
  card.className = `review-card type-${typeClass} reveal`;
  card.style.setProperty('--reveal-delay', '0s');
  card.dataset.id = review.id;
  card.dataset.type = review.type;
  card.dataset.stars = review.stars;

  const isLong = review.text.length > 80;

  card.innerHTML = `
    <div class="review-header">
      <div class="review-avatar ${typeClass}">${review.avatar}</div>
      <div class="review-user-info">
        <div class="review-username">${review.username}</div>
        <div class="review-date">${review.date}</div>
      </div>
      <span class="review-server">${review.server}</span>
    </div>
    <div class="review-stars">${renderStars(review.stars)}</div>
    <span class="review-tag ${typeClass}">${review.tag}</span>
    <div class="review-text" data-full="${review.text}">
      ${isLong ? review.text.slice(0, 80) + '…' : review.text}
    </div>
    ${isLong ? '<button class="review-expand">▼ 展开全部</button>' : ''}
    <div class="review-footer">
      <button class="review-action like-btn${review.userLiked ? ' liked' : ''}" data-id="${review.id}">
        <span class="icon">✦</span> <span class="count">${formatNumber(review.likes)}</span>
      </button>
      <button class="review-action dislike-btn${review.userDisliked ? ' disliked' : ''}" data-id="${review.id}">
        <span class="icon">✧</span> <span class="count">${formatNumber(review.dislikes)}</span>
      </button>
    </div>
  `;

  return card;
}

/* ================================================================
   4. 渲染评分概览
   ================================================================ */
function renderRatingOverview(reviews) {
  const total = reviews.length;
  const sum = reviews.reduce((acc, r) => acc + r.stars, 0);
  const avg = total > 0 ? (sum / total).toFixed(1) : '0.0';

  // 分布
  const dist = { 5: 0, 4: 0, 3: 0, 2: 0, 1: 0 };
  reviews.forEach(r => { dist[r.stars]++; });

  const positiveCount = reviews.filter(r => r.type === 'positive').length;
  const negativeCount = reviews.filter(r => r.type === 'negative').length;
  const recommendPct = total > 0 ? Math.round((positiveCount / total) * 100) : 0;

  // 主分数
  document.getElementById('avg-score').textContent = avg;
  document.getElementById('avg-stars').innerHTML = renderStars(Math.round(Number(avg)));

  // 统计数字（更新 data-count-to 给动画用，并直接更新显示的 .num 子元素）
  function setStat(id, value, hasPercent) {
    const el = document.getElementById(id);
    if (!el) return;
    el.setAttribute('data-count-to', value);
    const numSpan = el.querySelector('.num');
    if (numSpan) {
      numSpan.textContent = value;
    } else {
      el.textContent = hasPercent ? value + '%' : value;
    }
  }

  setStat('total-reviews', total);
  setStat('recommend-pct', recommendPct, false);
  setStat('positive-count', positiveCount);
  setStat('negative-count', negativeCount);

  // 分布条
  for (let i = 5; i >= 1; i--) {
    const pct = total > 0 ? (dist[i] / total) * 100 : 0;
    const bar = document.querySelector(`.rating-bar[data-stars="${i}"] .rating-bar-fill`);
    const count = document.querySelector(`.rating-bar[data-stars="${i}"] .rating-bar-count`);
    if (bar) {
      setTimeout(() => { bar.style.width = pct + '%'; }, 100);
    }
    if (count) {
      count.textContent = dist[i];
    }
  }

  // 更新 Tab 上的计数
  const countAll = document.getElementById('count-all');
  const countPos = document.getElementById('count-positive');
  const countNeg = document.getElementById('count-negative');
  if (countAll) countAll.textContent = total;
  if (countPos) countPos.textContent = positiveCount;
  if (countNeg) countNeg.textContent = negativeCount;
}

/* ================================================================
   5. 筛选 & 排序逻辑
   ================================================================ */
let currentFilter = 'all';
let currentSort = 'latest';
let currentSearch = '';

function renderReviews(reviews, filter, sort, search) {
  const grid = document.getElementById('review-grid');
  grid.innerHTML = '';

  // 筛选
  let filtered = [...reviews];
  if (filter === 'positive') {
    filtered = filtered.filter(r => r.type === 'positive');
  } else if (filter === 'negative') {
    filtered = filtered.filter(r => r.type === 'negative');
  }

  // 搜索（关键词匹配评测文本）
  if (search && search.trim()) {
    const kw = search.trim().toLowerCase();
    filtered = filtered.filter(r => r.text.toLowerCase().includes(kw));
  }

  // 排序 — 使用稳健的日期解析避免跨浏览器 bug
  function parseDate(dateStr) {
    if (!dateStr || typeof dateStr !== 'string') return 0;
    const parts = dateStr.split('-');
    if (parts.length === 3) {
      return new Date(+parts[0], +parts[1] - 1, +parts[2]).getTime();
    }
    return new Date(dateStr).getTime() || 0;
  }

  if (sort === 'latest') {
    filtered.sort((a, b) => parseDate(b.date) - parseDate(a.date));
  } else if (sort === 'oldest') {
    filtered.sort((a, b) => parseDate(a.date) - parseDate(b.date));
  } else if (sort === 'highest') {
    filtered.sort((a, b) => b.stars - a.stars || parseDate(b.date) - parseDate(a.date));
  } else if (sort === 'lowest') {
    filtered.sort((a, b) => a.stars - b.stars || parseDate(b.date) - parseDate(a.date));
  } else if (sort === 'popular') {
    filtered.sort((a, b) => b.likes - a.likes || parseDate(b.date) - parseDate(a.date));
  }

  if (filtered.length === 0) {
    grid.innerHTML = `
      <div class="no-reviews">
        <span class="symbol">◇</span>
        <p>没有找到匹配的玩家回声...</p>
      </div>
    `;
    return;
  }

  filtered.forEach(review => {
    grid.appendChild(createReviewCard(review));
  });

  // 重新绑定事件
  bindCardEvents();

  // 新渲染的卡片需要立即可见（已有 reveal 类但 observer 不会自动追踪新元素）
  // 调用 initScrollReveal 为新卡片绑定滚动揭示，同时让已入视口的卡片直接亮起
  refreshScrollReveal();
}

/* 刷新滚动揭示 — 每次重新渲染后调用 */
function refreshScrollReveal() {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('revealed');
        observer.unobserve(entry.target);
      }
    });
  }, {
    root: null,
    rootMargin: '0px 0px -40px 0px',
    threshold: 0.08
  });

  const revealEls = document.querySelectorAll('.reveal:not(.revealed)');
  
  // 给 review cards 设置交错延迟（针对尚未揭示的）
  const cards = document.querySelectorAll('.review-card.reveal:not(.revealed)');
  cards.forEach((card, i) => {
    card.style.setProperty('--reveal-delay', `${i * 0.02}s`);
  });

  if (revealEls.length === 0) return;

  revealEls.forEach(el => observer.observe(el));

  // 立即检查哪些已经在视口中
  setTimeout(() => {
    revealEls.forEach(el => {
      const rect = el.getBoundingClientRect();
      const isVisible = rect.top < window.innerHeight - 40;
      if (isVisible) {
        el.classList.add('revealed');
        observer.unobserve(el);
      }
    });
  }, 50);
}

function bindCardEvents() {
  // 展开/收起
  document.querySelectorAll('.review-expand').forEach(btn => {
    btn.addEventListener('click', function () {
      const textEl = this.previousElementSibling;
      const full = textEl.dataset.full;
      if (textEl.classList.contains('expanded')) {
        textEl.classList.remove('expanded');
        textEl.textContent = full.slice(0, 80) + '…';
        this.textContent = '▼ 展开全部';
      } else {
        textEl.classList.add('expanded');
        textEl.textContent = full;
        this.textContent = '▲ 收起';
      }
    });
  });

  // 点赞
  document.querySelectorAll('.like-btn').forEach(btn => {
    btn.addEventListener('click', function () {
      const id = parseInt(this.dataset.id);
      const review = reviewsData.find(r => r.id === id);
      if (!review) return;

      if (review.userLiked) {
        review.likes--;
        review.userLiked = false;
        recordLike(id, 'unlike');
      } else {
        // 如果之前是踩的状态，先取消踩
        if (review.userDisliked) {
          review.dislikes--;
          review.userDisliked = false;
        }
        review.likes++;
        review.userLiked = true;
        recordLike(id, 'like');
      }
      this.querySelector('.count').textContent = formatNumber(review.likes);

      // 更新同一个卡片的 dislike 按钮状态
      updateSiblingButtons(this, review);
      saveReviews(reviewsData);
      // ★ 同步到服务端
      syncLikeToServer(id, 'like', review.userLiked);
    });
  });

  // 踩
  document.querySelectorAll('.dislike-btn').forEach(btn => {
    btn.addEventListener('click', function () {
      const id = parseInt(this.dataset.id);
      const review = reviewsData.find(r => r.id === id);
      if (!review) return;

      if (review.userDisliked) {
        review.dislikes--;
        review.userDisliked = false;
        recordLike(id, 'undislike');
      } else {
        // 如果之前是赞的状态，先取消赞
        if (review.userLiked) {
          review.likes--;
          review.userLiked = false;
        }
        review.dislikes++;
        review.userDisliked = true;
        recordLike(id, 'dislike');
      }
      this.querySelector('.count').textContent = formatNumber(review.dislikes);

      // 更新同一个卡片的 like 按钮状态
      updateSiblingButtons(this, review);
      saveReviews(reviewsData);
      // ★ 同步到服务端
      syncLikeToServer(id, 'dislike', review.userDisliked);
    });
  });
}

function updateSiblingButtons(clickedBtn, review) {
  const card = clickedBtn.closest('.review-card');
  if (!card) return;
  const likeBtn = card.querySelector('.like-btn');
  const dislikeBtn = card.querySelector('.dislike-btn');

  if (likeBtn) {
    likeBtn.classList.toggle('liked', review.userLiked);
    likeBtn.querySelector('.count').textContent = formatNumber(review.likes);
  }
  if (dislikeBtn) {
    dislikeBtn.classList.toggle('disliked', review.userDisliked);
    dislikeBtn.querySelector('.count').textContent = formatNumber(review.dislikes);
  }
}

/* ★ 同步点赞/踩到服务端（静默失败，不影响本地体验） */
function syncLikeToServer(reviewId, type, isActive) {
  if (!API_PREFIX) return;
  fetch(API_PREFIX + 'toggle-like', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ id: reviewId, type: type, active: isActive })
  }).catch(() => {
    // 服务端不可用时静默忽略，本地状态已保存
  });
}

/* ================================================================
   6. Tab 切换
   ================================================================ */
function initFilters() {
  const tabs = document.querySelectorAll('.filter-tab');
  const sortSelect = document.getElementById('sort-select');

  tabs.forEach(tab => {
    tab.addEventListener('click', function () {
      tabs.forEach(t => t.classList.remove('active'));
      this.classList.add('active');
      currentFilter = this.dataset.filter;
      renderReviews(reviewsData, currentFilter, currentSort, currentSearch);
    });
  });

  sortSelect.addEventListener('change', function () {
    currentSort = this.value;
    renderReviews(reviewsData, currentFilter, currentSort, currentSearch);
  });
}

/* ================================================================
   7. 搜索
   ================================================================ */
function initSearch() {
  const input = document.getElementById('search-input');
  const clearBtn = document.getElementById('search-clear');

  if (!input) return;

  let debounceTimer;
  input.addEventListener('input', function () {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(() => {
      currentSearch = input.value;
      clearBtn.style.display = currentSearch ? 'block' : 'none';
      renderReviews(reviewsData, currentFilter, currentSort, currentSearch);
    }, 280);
  });

  if (clearBtn) {
    clearBtn.addEventListener('click', function () {
      input.value = '';
      currentSearch = '';
      clearBtn.style.display = 'none';
      renderReviews(reviewsData, currentFilter, currentSort, currentSearch);
      input.focus();
    });
  }
}

/* ================================================================
   8. 滚动揭示动画
   ================================================================ */
function initScrollReveal() {
  const revealEls = document.querySelectorAll('.reveal');
  if (revealEls.length === 0) return;

  // 给 review cards 设置交错延迟
  const cards = document.querySelectorAll('.review-card.reveal');
  cards.forEach((card, i) => {
    card.style.setProperty('--reveal-delay', `${i * 0.06}s`);
  });

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('revealed');
        observer.unobserve(entry.target);
      }
    });
  }, {
    root: null,
    rootMargin: '0px 0px -40px 0px',
    threshold: 0.08
  });

  revealEls.forEach(el => observer.observe(el));
}

/* ================================================================
   8b. 新评测卡片滚动揭示
   ================================================================ */
function revealNewCard(card) {
  // 设置短延迟
  card.style.setProperty('--reveal-delay', '0.1s');
  // 重置 reveal 状态
  card.classList.remove('revealed');
  // 强制回流后添加 revealed
  void card.offsetWidth;
  card.classList.add('revealed');
}

/* ================================================================
   9. 撰写评测
   ================================================================ */
function getTodayString() {
  const d = new Date();
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

function initWriteReview() {
  const stars = document.querySelectorAll('.write-review-stars-input .star');
  let selected = 0;

  const hiddenStars = document.getElementById('hidden-stars');

  stars.forEach((star, index) => {
    star.addEventListener('click', function () {
      selected = index + 1;
      stars.forEach((s, i) => {
        s.classList.toggle('active', i < selected);
      });
      // 同步到隐藏字段（表单直提时使用）
      if (hiddenStars) hiddenStars.value = selected;
    });

    star.addEventListener('mouseenter', function () {
      stars.forEach((s, i) => {
        s.classList.toggle('active', i <= index);
      });
    });

    star.addEventListener('mouseleave', function () {
      stars.forEach((s, i) => {
        s.classList.toggle('active', i < selected);
      });
    });
  });

  // 提交按钮 / 表单提交
  const reviewForm = document.getElementById('review-form');
  const submitBtn = document.getElementById('submit-review');
  const textarea = document.getElementById('review-textarea');
  const nicknameInput = document.getElementById('review-nickname');

  // 表单提交 — 纯同步本地处理 + 后台 API
  if (reviewForm) {
    reviewForm.addEventListener('submit', function (e) {
      e.preventDefault();

      const text = textarea.value.trim();
      const nickname = nicknameInput.value.trim();
      const starsVal = hiddenStars ? parseInt(hiddenStars.value) : (selected || 0);

      if (!nickname) { alert('请写上你的命运之名 📜'); nicknameInput.focus(); return; }
      if (starsVal < 1) { alert('请先为地球online打分 ⚖️'); return; }
      if (!text) { alert('请写下你的玩家感受 📝'); textarea.focus(); return; }

      // ★ 先提交到服务端验证，再决定是否锁定
      submitBtn.disabled = true;
      submitBtn.textContent = '✦ 提交中…';

      fetch(API_PREFIX + 'submit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: nickname, stars: starsVal, text: text })
      }).then(r => {
        // 403 表示 IP 重复，也需要解析 JSON
        return r.json();
      }).then(data => {
        if (data && data.success && data.review) {
          // ★ 提交成功：锁定表单
          lockReviewForm();
          data.review.userLiked = false;
          data.review.userDisliked = false;
          reviewsData.push(data.review);
          saveReviews(reviewsData);
          renderRatingOverview(reviewsData);
          renderReviews(reviewsData, currentFilter, currentSort, currentSearch);
        } else if (data && (data.code === 'IP_EXISTS' || data.code === 'DEVICE_EXISTS')) {
          // ★ 服务端检测到设备/IP 重复：强制锁定
          lockReviewForm();
          alert(data.message || '你已提交过评测，每个命运的印记只能回响一次 ✦');
        } else {
          // 服务端返回其他错误，降级到本地存储
          lockReviewForm();
          handleLocalSubmit(nickname, starsVal, text);
          saveReviews(reviewsData);
          renderRatingOverview(reviewsData);
          renderReviews(reviewsData, currentFilter, currentSort, currentSearch);
        }
      }).catch(() => {
        // 网络错误，降级到本地存储
        lockReviewForm();
        handleLocalSubmit(nickname, starsVal, text);
        saveReviews(reviewsData);
        renderRatingOverview(reviewsData);
        renderReviews(reviewsData, currentFilter, currentSort, currentSearch);
      });

      // 先清空表单
      textarea.value = '';
      nicknameInput.value = '';
      if (hiddenStars) hiddenStars.value = 0;
      selected = 0;
      stars.forEach(s => s.classList.remove('active'));
    });
  }

  function handleLocalSubmit(nickname, starsVal, text) {
    const type = starsVal >= 4 ? 'positive' : 'negative';
    reviewsData.push({
      id: nextId++,
      type,
      username: nickname,
      avatar: AVATAR_POOL[Math.floor(Math.random() * AVATAR_POOL.length)],
      server: '亚服·未知',
      date: getTodayString(),
      stars: starsVal,
      tag: getTag(type, starsVal),
      text,
      likes: 0, dislikes: 0,
      userLiked: false, userDisliked: false
    });
  }

// 清空按钮
  const resetBtn = document.getElementById('reset-review');
  resetBtn.addEventListener('click', function () {
    textarea.value = '';
    nicknameInput.value = '';
    selected = 0;
    stars.forEach(s => s.classList.remove('active'));
    textarea.focus();
  });
}

/* ================================================================
   10. 统计数字递增动画
   ================================================================ */
function animateCounters() {
  const counters = document.querySelectorAll('[data-count-to]');
  counters.forEach(el => {
    const target = parseInt(el.dataset.countTo);
    // 如果有子元素（如 <span class="num"> 包裹数字），更新子元素内容
    const numEl = el.querySelector('.num');
    const container = numEl || el;
    const duration = 2000;
    const start = performance.now();

    function update(now) {
      const elapsed = now - start;
      const progress = Math.min(elapsed / duration, 1);
      // easeOutCubic
      const ease = 1 - Math.pow(1 - progress, 3);
      const current = Math.round(ease * target);
      container.textContent = current;
      if (progress < 1) {
        requestAnimationFrame(update);
      } else {
        container.textContent = target;
      }
    }
    requestAnimationFrame(update);
  });
}

/* ================================================================
   11. 初始化
   ================================================================ */
document.addEventListener('DOMContentLoaded', async function () {
  // 尝试从服务端加载数据（同时获取 IP 锁定状态）
  const serverReviews = await fetchReviewsFromServer();
  if (serverReviews && serverReviews.length > 0) {
    // ★ 合并本地点赞状态（服务端数据没有 userLiked/userDisliked）
    mergeLikesState(serverReviews);
    reviewsData = serverReviews;
    saveReviews(reviewsData);
    // 更新 nextId
    nextId = reviewsData.reduce((max, r) => Math.max(max, r.id), 0) + 1;
  } else if (reviewsData.length === 0) {
    // 服务端和本地都没有数据时，才使用默认数据（但不写入 localStorage）
    reviewsData = JSON.parse(JSON.stringify(DEFAULT_REVIEWS));
    mergeLikesState(reviewsData);
  } else {
    // 本地有数据但服务端不可用
    mergeLikesState(reviewsData);
  }

  // ★★★ 锁定检测 — 必须在 initWriteReview 之前完成 ★★★
  // 优先级：服务端 IP 检测 > Cookie > localStorage > URL 参数
  var shouldLock = false;
  var urlLock = window.location.search.includes('success=1');

  // 1. 服务端 IP 检测（最高优先级，与 reviews 一起返回）
  if (window.__serverHasSubmitted === true) {
    shouldLock = true;
    console.log('🔒 服务端 IP 检测：已提交，锁定表单');
  }

  // 2. Cookie 检测
  if (!shouldLock && isReviewLocked()) {
    shouldLock = true;
    console.log('🔒 Cookie/localStorage 检测：已提交，锁定表单');
  }

  // 3. URL 参数检测（表单直提重定向后）
  if (urlLock) {
    shouldLock = true;
    window.history.replaceState(null, '', 'index.html');
  }

  // 如果需要锁定，在初始化表单之前就替换 DOM
  if (shouldLock) {
    lockReviewForm();
  }

  // 星空的低语
  initStarfield();

  // 统计概览
  renderRatingOverview(reviewsData);

  // 渲染所有评测（默认全部、最新、无搜索）
  renderReviews(reviewsData, 'all', 'latest', '');

  // 筛选控件
  initFilters();

  // 搜索
  initSearch();

  // 撰写评测（只有未锁定时才初始化交互）
  if (!shouldLock) {
    initWriteReview();
  }

  // 数字动画
  animateCounters();

  // 滚动揭示动画
  refreshScrollReveal();

  // 快捷键 Ctrl+Shift+A → 管理后台
  document.addEventListener('keydown', function(e) {
    if (e.ctrlKey && e.shiftKey && (e.key === 'A' || e.key === 'a')) {
      e.preventDefault();
      window.location.href = 'admin.html';
    }
  });

  // 控制台彩蛋
  console.log('%c✦ 地球online ✦', 'font-size:24px; color:#d4a853; font-weight:bold;');
  console.log('%c你发现了隐藏的密文……这个世界远比你看到的复杂。', 'color:#9a95a0; font-style:italic;');
  console.log('%c🔮 命运之轮正在转动。', 'color:#f0d48a;');
});


