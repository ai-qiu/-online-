<?php
// ★ 防缓存
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0, private');
header('Pragma: no-cache');
header('Expires: 0');

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }

$DATA_DIR = __DIR__ . '/data';

function readJSON($file, $default = null) {
    return file_exists($file) ? (json_decode(file_get_contents($file), true) ?? $default) : $default;
}

function writeJSON($file, $data) {
    $dir = dirname($file);
    if (!is_dir($dir) && !@mkdir($dir, 0755, true)) return false;
    return file_put_contents($file, json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT)) !== false;
}

function jsonResponse($data, $code = 200) {
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function getPOST($key, $default = null) {
    $input = json_decode(file_get_contents('php://input'), true) ?? [];
    return $input[$key] ?? $_POST[$key] ?? $default;
}

// 文件路径
$REVIEWS_FILE    = $DATA_DIR . '/reviews.json';
$META_FILE       = $DATA_DIR . '/meta.json';
$CONFIG_FILE     = $DATA_DIR . '/config.json';
$DEVICES_FILE    = $DATA_DIR . '/submitted-devices.json';

// ★ 获取或创建设备令牌（核心：替代 IP 做去重）
// 每个浏览器首次访问时，服务端通过 Cookie 分配一个唯一 UUID
// 这个 UUID 跟随浏览器，不同设备/浏览器有不同 UUID
function getOrCreateDeviceToken() {
    $cookieName = 'elo_device';
    $token = $_COOKIE[$cookieName] ?? null;

    // 验证 token 格式（必须是 UUID v4 格式）
    if ($token && preg_match('/^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/i', $token)) {
        return $token;
    }

    // 生成新 UUID v4
    $data = random_bytes(16);
    $data[6] = chr(ord($data[6]) & 0x0f | 0x40); // version 4
    $data[8] = chr(ord($data[8]) & 0x3f | 0x80); // variant
    $token = vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));

    // 设置 Cookie：10 年有效，全站路径
    setcookie($cookieName, $token, time() + 86400 * 3650, '/', '', false, false);

    return $token;
}

// 读取已提交设备令牌列表
function getSubmittedDevices($file) {
    $devices = readJSON($file, []);
    return is_array($devices) ? $devices : [];
}

$action = $_GET['action'] ?? '';

// ★ 确保 data 目录和必要文件存在
if (!is_dir($DATA_DIR)) {
    @mkdir($DATA_DIR, 0755, true);
}
if (!file_exists($DEVICES_FILE)) {
    writeJSON($DEVICES_FILE, []);
}

// ★ 每次请求都确保设备令牌 Cookie 被设置
$deviceToken = getOrCreateDeviceToken();

switch ($action) {

    // ======= 诊断接口 =======
    case 'debug':
        $devices = getSubmittedDevices($DEVICES_FILE);
        jsonResponse([
            'success' => true,
            'deviceToken' => $deviceToken,
            'deviceCookie' => $_COOKIE['elo_device'] ?? 'N/A',
            'lockedCookie' => $_COOKIE['elo_locked'] ?? 'N/A',
            'submittedDevices' => $devices,
            'devicesFileExists' => file_exists($DEVICES_FILE),
            'dataDirWritable' => is_writable($DATA_DIR),
            'hasSubmitted' => in_array($deviceToken, $devices)
        ]);
        break;

    // ======= 获取评测 =======
    case 'reviews':
        $reviews = readJSON($REVIEWS_FILE, []);
        $meta = readJSON($META_FILE, ['nextId' => 11, 'deletedCount' => 0]);
        $devices = getSubmittedDevices($DEVICES_FILE);
        $hasSubmitted = in_array($deviceToken, $devices);
        jsonResponse(['success' => true, 'reviews' => $reviews, 'meta' => $meta, 'hasSubmitted' => $hasSubmitted]);
        break;

    // ======= 提交评测 =======
    case 'submit':
        // ★ 设备令牌去重检查（替代 IP 去重，每台设备唯一）
        $devices = getSubmittedDevices($DEVICES_FILE);
        if (in_array($deviceToken, $devices)) {
            jsonResponse(['success' => false, 'code' => 'DEVICE_EXISTS', 'message' => '你已提交过评测，每个命运的印记只能回响一次 ✦'], 403);
        }

        $username = getPOST('username');
        $stars = (int)getPOST('stars');
        $text = getPOST('text');

        if (!$username || trim($username) === '') jsonResponse(['success' => false, 'message' => '请填写你的代号'], 400);
        if ($stars < 1 || $stars > 5) jsonResponse(['success' => false, 'message' => '请选择评分'], 400);
        if (!$text || trim($text) === '') jsonResponse(['success' => false, 'message' => '请写下评测内容'], 400);

        $reviews = readJSON($REVIEWS_FILE, []);
        $meta = readJSON($META_FILE, ['nextId' => 11, 'deletedCount' => 0]);
        $avatarPool = ['🔮','🌙','🃏','📜','⚖️','💀','🌪️','⏳','🕳️','📖','🧙','🪐','🌈','🐉','🎭'];
        $tagMap = [5 => '强烈推荐', 4 => '推荐', 3 => '差强人意', 2 => '体验糟糕', 1 => '极度不公'];

        $newReview = [
            'id' => $meta['nextId'],
            'type' => $stars >= 4 ? 'positive' : 'negative',
            'username' => trim($username),
            'avatar' => $avatarPool[array_rand($avatarPool)],
            'server' => '亚服·未知',
            'date' => date('Y-m-d'),
            'stars' => $stars,
            'tag' => $tagMap[$stars] ?? '未知',
            'text' => trim($text),
            'likes' => 0, 'dislikes' => 0
        ];

        $reviews[] = $newReview;
        $meta['nextId']++;

        // ★ Cookie 锁定标记：365 天有效
        setcookie('elo_locked', '1', time() + 86400 * 365, '/', '', false, false);

        // ★ 记录设备令牌（服务端去重）
        if (!in_array($deviceToken, $devices)) {
            $devices[] = $deviceToken;
        }
        $deviceWriteOk = writeJSON($DEVICES_FILE, $devices);
        if (!$deviceWriteOk) {
            error_log('地球online: submitted-devices.json 写入失败，路径=' . $DEVICES_FILE);
        }

        $ok1 = writeJSON($REVIEWS_FILE, $reviews);
        $ok2 = writeJSON($META_FILE, $meta);

        if (!$ok1 || !$ok2) {
            jsonResponse(['success' => false, 'message' => '存储失败，请确保 data/ 目录可写入'], 500);
            break;
        }

        // 非 AJAX 请求（浏览器原生表单提交）→ 重定向到首页
        if (empty($_SERVER['HTTP_X_REQUESTED_WITH']) || $_SERVER['HTTP_X_REQUESTED_WITH'] !== 'XMLHttpRequest') {
            header('Location: index.html?success=1');
            exit;
        }

        jsonResponse(['success' => true, 'review' => $newReview]);
        break;

    // ======= 点赞/踩 =======
    case 'toggle-like':
        $id = (int)getPOST('id');
        $type = getPOST('type'); // 'like' or 'dislike'
        $active = getPOST('active'); // true=点赞/踩, false=取消

        if (!$id || !in_array($type, ['like', 'dislike'])) {
            jsonResponse(['success' => false, 'message' => '参数错误'], 400);
        }

        $reviews = readJSON($REVIEWS_FILE, []);
        $found = false;
        foreach ($reviews as &$r) {
            if ($r['id'] === $id) {
                $found = true;
                if ($type === 'like') {
                    $r['likes'] = max(0, ($r['likes'] ?? 0) + ($active ? 1 : -1));
                } else {
                    $r['dislikes'] = max(0, ($r['dislikes'] ?? 0) + ($active ? 1 : -1));
                }
                break;
            }
        }
        unset($r);

        if (!$found) jsonResponse(['success' => false, 'message' => '评测不存在'], 404);

        writeJSON($REVIEWS_FILE, $reviews);
        jsonResponse(['success' => true]);
        break;

    // ======= 管理员登录 =======
    case 'login':
        $password = getPOST('password');
        $config = readJSON($CONFIG_FILE, ['adminPassword' => 'admin123']);
        $ap = $config['adminPassword'] ?? 'admin123';
        jsonResponse($password === $ap ? ['success' => true] : ['success' => false, 'message' => '密钥错误'], $password === $ap ? 200 : 401);
        break;

    // ======= 管理员删除 =======
    case 'delete-review':
        $id = (int)getPOST('id');
        $password = getPOST('password');
        $config = readJSON($CONFIG_FILE, ['adminPassword' => 'admin123']);
        $ap = $config['adminPassword'] ?? 'admin123';
        if ($password !== $ap) jsonResponse(['success' => false, 'message' => '未授权的操作'], 401);

        $reviews = readJSON($REVIEWS_FILE, []);
        $found = -1; $removed = null;
        foreach ($reviews as $i => $r) { if ($r['id'] === $id) { $found = $i; $removed = $r; break; } }
        if ($found === -1) jsonResponse(['success' => false, 'message' => '评测不存在'], 404);

        array_splice($reviews, $found, 1);
        writeJSON($REVIEWS_FILE, $reviews);
        $meta = readJSON($META_FILE, ['nextId' => 11, 'deletedCount' => 0]);
        $meta['deletedCount']++;
        writeJSON($META_FILE, $meta);
        jsonResponse(['success' => true, 'review' => $removed, 'deletedCount' => $meta['deletedCount']]);
        break;

    // ======= 修改密码 =======
    case 'change-password':
        $old = getPOST('oldPassword');
        $new = getPOST('newPassword');
        if (!$old || !$new) jsonResponse(['success' => false, 'message' => '请提供密码'], 400);
        if (strlen($new) < 4) jsonResponse(['success' => false, 'message' => '新密码至少 4 个字符'], 400);
        $config = readJSON($CONFIG_FILE, ['adminPassword' => 'admin123']);
        if ($old !== ($config['adminPassword'] ?? 'admin123')) jsonResponse(['success' => false, 'message' => '旧密码错误'], 401);
        if ($old === $new) jsonResponse(['success' => false, 'message' => '新密码不能与旧密码相同'], 400);
        $config['adminPassword'] = $new;
        writeJSON($CONFIG_FILE, $config);
        jsonResponse(['success' => true, 'message' => '密码修改成功']);
        break;

    default:
        jsonResponse(['success' => false, 'message' => '未知操作'], 404);
        break;
}
