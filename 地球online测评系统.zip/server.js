/**
 * 地球online — 管理服务器
 * 功能：IP 限制提交、服务端数据持久化、管理接口
 *
 * 启动方式： node server.js
 * 默认端口： 3000
 *
 * 访问：
 *   http://localhost:3000     — 前台评测页
 *   http://localhost:3000/admin.html — 后台管理
 */

const express = require('express');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// 数据文件路径
const DATA_DIR = path.join(__dirname, 'data');
const REVIEWS_FILE = path.join(DATA_DIR, 'reviews.json');
const IPS_FILE = path.join(DATA_DIR, 'submitted-ips.json');
const META_FILE = path.join(DATA_DIR, 'meta.json');
const CONFIG_FILE = path.join(DATA_DIR, 'config.json');

// 确保 data 目录存在
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// 默认配置
const DEFAULT_CONFIG = {
  adminPassword: 'admin123'
};

// ---------- 数据读写 ----------
function readJSON(filePath, fallback) {
  try {
    if (fs.existsSync(filePath)) {
      return JSON.parse(fs.readFileSync(filePath, 'utf-8'));
    }
  } catch (e) {
    console.warn('读取失败，使用默认值:', filePath, e.message);
  }
  return fallback;
}

function writeJSON(filePath, data) {
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf-8');
}

// 获取客户端 IP
function getClientIP(req) {
  const forwarded = req.headers['x-forwarded-for'];
  if (forwarded) {
    return forwarded.split(',')[0].trim();
  }
  return req.socket.remoteAddress || req.ip || 'unknown';
}

// ---------- 中间件 ----------
app.use(express.json());

// 日志
app.use((req, res, next) => {
  const ip = getClientIP(req);
  console.log(`[${new Date().toISOString()}] ${req.method} ${req.url} — ${ip}`);
  next();
});

// 静态文件服务
app.use(express.static(__dirname, {
  maxAge: '1h',
  etag: true
}));

// ---------- 初始化默认数据 ----------
function initDefaultData() {
  const reviewsFile = REVIEWS_FILE;
  const ipsFile = IPS_FILE;
  const metaFile = META_FILE;

  if (!fs.existsSync(reviewsFile)) {
    // 从 app.js 获取默认评测数据
    const defaultReviews = [
      { id: 1, type: 'positive', username: '天命占星人', avatar: '🔮', server: '欧服·阿尔法', date: '2077-03-15', stars: 5, tag: '强烈推荐', text: '开局随机到北欧服务器，出生自带高福利社会属性，新手礼包直接送16年义务教育+全民医保。画面细节拉满，四季轮换真实到令人发指，NPC交互深度远超同类产品。虽然前期练级比较漫长，但坚持到20级后技能树逐渐丰富，值得长期投入。', likes: 2847, dislikes: 312 },
      { id: 2, type: 'positive', username: '星盘观测者', avatar: '🌙', server: '亚服·伽马', date: '2077-02-28', stars: 4, tag: '推荐', text: '自由度极高，你可以选择任何职业路线，没有强制主线任务。但新手教程约等于无，全靠自己摸索，前10级特别劝退。建议官方出一个更好的出生引导系统，不然新手死亡率太高了。不过熬过前期之后真香。', likes: 1923, dislikes: 456 },
      { id: 3, type: 'positive', username: '命运编织者', avatar: '🃏', server: '亚服·贝塔', date: '2076-12-01', stars: 5, tag: '神作', text: '我在这游戏里已经泡了8760个小时（约等于现实时间1年），依然觉得每天都有新内容。最绝的是这游戏的NPC每个都有独立人格和错综复杂的关系网，你永远不知道下一秒会触发什么隐藏剧情。唯一缺点：没法存档读档，一步走错可能影响整个周目。', likes: 3652, dislikes: 189 },
      { id: 4, type: 'positive', username: '秘仪学者', avatar: '📜', server: '亚服·阿尔法', date: '2077-01-20', stars: 4, tag: '值得一试', text: '音乐和美术无可挑剔，每个地图的场景设计都看得出花了血本。社交系统也是我见过最真实的——你永远不知道队友会不会在关键时刻下线。扣一星是因为最近的版本更新后，房价物价系统数值膨胀有点严重。', likes: 1567, dislikes: 534 },
      { id: 5, type: 'positive', username: '灵摆占卜师', avatar: '⚖️', server: '欧服·伽马', date: '2076-11-11', stars: 5, tag: '现象级', text: '二周目中选了hard模式开局，果然比一周目刺激多了。建议新手先选简单模式熟悉机制。这游戏的沉浸感无与伦比，已经安利给了所有还在排队等转生的朋友。', likes: 2210, dislikes: 298 },
      { id: 6, type: 'negative', username: '破灭预言家', avatar: '💀', server: '亚服·阿尔法', date: '2077-03-10', stars: 1, tag: '极度不公', text: '氪金系统极度不平衡！有些玩家开局就是满配账号——出生在富裕家庭、高颜值、高智商属性点全满。而我们这些零氪玩家辛辛苦苦练到30级，还不如人家一个首充礼包。这游戏根本不公平，强烈建议所有玩家罢玩抗议！', likes: 5234, dislikes: 1021 },
      { id: 7, type: 'negative', username: '虚空旅者', avatar: '🌪️', server: '亚服·德尔塔', date: '2077-02-14', stars: 2, tag: '体验糟糕', text: '服务器卡顿严重，每天高峰时段都有明显延迟，有时候关键操作会直接卡掉线重连。特别是某些地图（早高峰地铁站、热门景区）简直PPT一样。优化做了这么多年还是这德行，程序员是摸鱼去了吗？', likes: 3891, dislikes: 765 },
      { id: 8, type: 'negative', username: '末日时钟匠', avatar: '⏳', server: '美服·贝塔', date: '2077-01-05', stars: 1, tag: '退游警告', text: 'PvP模式做得一塌糊涂！高等级玩家随便屠戮新手村，GM完全不管。竞技场里全是顶级装备的氪佬，零氪玩家进去就是送人头。这游戏已经彻底变成了pay-to-win，失望透顶，已卸载。', likes: 4456, dislikes: 892 },
      { id: 9, type: 'negative', username: '深渊回响', avatar: '🕳️', server: '亚服·阿尔法', date: '2076-12-24', stars: 2, tag: 'BUG太多', text: '恶性BUG多到令人发指：上周我在街上走着莫名其妙触发了一个"失业"DEBUFF，持续了6个月还没消除；朋友更惨，遇到了"房贷"永久绑定任务，据说要还30年现实时间才能完成。建议修复再上线。', likes: 3125, dislikes: 643 },
      { id: 10, type: 'negative', username: '终末记录官', avatar: '📖', server: '亚服·泽塔', date: '2076-10-31', stars: 3, tag: '差强人意', text: '中等偏下的体验。世界观确实宏大，但日常任务（上班/上学）重复度太高，收益又低。而且最近版本的健康系统更新后，熬夜挂机被强制下线了。说是为了玩家好，但我觉得管得太宽了。给三星是因为偶尔触发的隐藏任务（旅行/恋爱/奇遇）确实好玩。', likes: 1834, dislikes: 412 }
    ];
    writeJSON(reviewsFile, defaultReviews);
    console.log('✅ 已创建默认评测数据 (' + defaultReviews.length + ' 条)');
  }

  if (!fs.existsSync(ipsFile)) {
    writeJSON(ipsFile, []);
  }

  if (!fs.existsSync(metaFile)) {
    writeJSON(metaFile, { nextId: 11, deletedCount: 0 });
  }

  const configFile = CONFIG_FILE;
  if (!fs.existsSync(configFile)) {
    writeJSON(configFile, DEFAULT_CONFIG);
    console.log('✅ 已创建管理员配置，默认密码: admin123');
  }
}

// ---------- 存储操作 ----------
function getReviews() {
  return readJSON(REVIEWS_FILE, []);
}

function saveReviews(data) {
  writeJSON(REVIEWS_FILE, data);
}

function getSubmittedIPs() {
  return readJSON(IPS_FILE, []);
}

function saveSubmittedIPs(ips) {
  writeJSON(IPS_FILE, ips);
}

function getMeta() {
  return readJSON(META_FILE, { nextId: 11, deletedCount: 0 });
}

function saveMeta(meta) {
  writeJSON(META_FILE, meta);
}

/* ---------- 配置（密码）存储 ---------- */
function getConfig() {
  return readJSON(CONFIG_FILE, DEFAULT_CONFIG);
}

function saveConfig(config) {
  writeJSON(CONFIG_FILE, config);
}

// 获取管理密码（从配置读取）
function getAdminPassword() {
  const config = getConfig();
  return config.adminPassword || DEFAULT_CONFIG.adminPassword;
}

// ---------- API 路由 ----------

// 获取评测数据
app.get('/api/reviews', (req, res) => {
  let reviews = getReviews();
  // 如果数据为空或损坏，自动重新初始化
  if (!Array.isArray(reviews) || reviews.length === 0) {
    initDefaultData();
    reviews = getReviews();
  }
  const meta = getMeta();
  res.json({ success: true, reviews, meta });
});

// 强制保存数据到 JSON 文件
app.post('/api/admin/save', (req, res) => {
  const { password } = req.body;
  const adminPassword = getAdminPassword();
  if (password !== adminPassword) {
    return res.status(401).json({ success: false, message: '未授权的操作' });
  }
  try {
    const reviews = getReviews();
    const meta = getMeta();
    saveReviews(reviews);
    saveMeta(meta);
    res.json({ success: true, message: '数据已保存到 data/reviews.json', count: reviews.length });
  } catch (e) {
    res.status(500).json({ success: false, message: e.message });
  }
});

// 检查 IP 是否已提交
app.get('/api/check-ip', (req, res) => {
  const ip = getClientIP(req);
  const ips = getSubmittedIPs();
  const hasSubmitted = ips.includes(ip);
  res.json({ success: true, ip, hasSubmitted });
});

// 提交评测（含 IP 检查）
app.post('/api/submit-review', (req, res) => {
  const ip = getClientIP(req);
  // 确保数据已初始化
  let ips = getSubmittedIPs();
  if (!Array.isArray(ips)) {
    ips = [];
    saveSubmittedIPs(ips);
  }

  // IP 去重检查
  if (ips.includes(ip)) {
    return res.status(403).json({
      success: false,
      code: 'IP_EXISTS',
      message: '你已提交过评测，每个命运的印记只能回响一次 ✦'
    });
  }

  const { username, stars, text } = req.body;

  if (!username || !username.trim()) {
    return res.status(400).json({ success: false, message: '请填写你的代号' });
  }
  if (!stars || stars < 1 || stars > 5) {
    return res.status(400).json({ success: false, message: '请选择评分' });
  }
  if (!text || !text.trim()) {
    return res.status(400).json({ success: false, message: '请写下评测内容' });
  }

  const reviews = getReviews();
  const meta = getMeta();
  const avatarPool = ['🔮','🌙','🃏','📜','⚖️','💀','🌪️','⏳','🕳️','📖','🧙','🪐','🌈','🐉','🎭'];

  const type = stars >= 4 ? 'positive' : 'negative';
  const tagMap = { 5:'强烈推荐', 4:'推荐', 3:'差强人意', 2:'体验糟糕', 1:'极度不公' };

  const newReview = {
    id: meta.nextId,
    type,
    username: username.trim(),
    avatar: avatarPool[Math.floor(Math.random() * avatarPool.length)],
    server: '亚服·未知',
    date: new Date().toISOString().slice(0, 10),
    stars,
    tag: tagMap[stars] || '未知',
    text: text.trim(),
    likes: 0,
    dislikes: 0
  };

  reviews.push(newReview);
  saveReviews(reviews);

  meta.nextId++;
  saveMeta(meta);

  // 记录 IP
  ips.push(ip);
  saveSubmittedIPs(ips);

  console.log(`✅ IP ${ip} 提交了 ${stars} 星评测「${newReview.username}」`);

  res.json({ success: true, review: newReview });
});

// 管理员登录验证
app.post('/api/admin/login', (req, res) => {
  const { password } = req.body;
  const adminPassword = getAdminPassword();

  if (password === adminPassword) {
    const ip = getClientIP(req);
    console.log(`🔑 管理员登录成功 — ${ip}`);
    res.json({ success: true });
  } else {
    res.status(401).json({ success: false, message: '密钥错误' });
  }
});

// 管理员删除评测（需密码验证）
app.post('/api/admin/delete-review', (req, res) => {
  const { id, password } = req.body;
  const adminPassword = getAdminPassword();

  if (password !== adminPassword) {
    return res.status(401).json({ success: false, message: '未授权的操作' });
  }

  const reviews = getReviews();
  const idx = reviews.findIndex(r => r.id === id);
  if (idx === -1) {
    return res.status(404).json({ success: false, message: '评测不存在' });
  }

  const removed = reviews.splice(idx, 1)[0];
  saveReviews(reviews);

  const meta = getMeta();
  meta.deletedCount = (meta.deletedCount || 0) + 1;
  saveMeta(meta);

  console.log(`🗑️ 管理员删除了评测 #${id}「${removed.username}」`);

  res.json({ success: true, review: removed, deletedCount: meta.deletedCount });
});

// 管理员修改密码
app.post('/api/admin/change-password', (req, res) => {
  const { oldPassword, newPassword } = req.body;

  if (!oldPassword || !newPassword) {
    return res.status(400).json({ success: false, message: '请提供旧密码和新密码' });
  }

  if (newPassword.length < 4) {
    return res.status(400).json({ success: false, message: '新密码至少需要 4 个字符' });
  }

  const adminPassword = getAdminPassword();
  if (oldPassword !== adminPassword) {
    return res.status(401).json({ success: false, message: '旧密码错误' });
  }

  if (oldPassword === newPassword) {
    return res.status(400).json({ success: false, message: '新密码不能与旧密码相同' });
  }

  const config = getConfig();
  config.adminPassword = newPassword;
  saveConfig(config);

  console.log(`🔑 管理员密码已修改`);
  res.json({ success: true, message: '密码修改成功' });
});

// ---------- 初始化 & 启动 ----------
initDefaultData();

app.listen(PORT, () => {
  console.log('');
  console.log('✦══════════════════════════════════════✦');
  console.log('  地球online · 管理服务器');
  console.log('  http://localhost:' + PORT);
  console.log('  http://localhost:' + PORT + '/admin.html  ← 管理后台');
  console.log('✦══════════════════════════════════════✦');
  console.log('');
  console.log('⚙️  默认密码: admin123');
  console.log('⚙️  每个 IP 仅可提交 1 次评测');
  console.log('⚙️  数据存储在 data/ 目录');
});
